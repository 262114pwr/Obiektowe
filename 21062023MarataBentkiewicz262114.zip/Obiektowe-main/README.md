System biblioteczny <br/>
Założenia:
1. zamówienie
2. wyszukiwanie
3. logowanie
4. anulowanie wypożyczenia
5. zarządzanie kontami (login + hasło)<br/>
Aplikacja webowa - Python Framework DJango<br/>
Baza plikowa - SQLite- książek<br/>

![Zrzut ekranu (6481)](https://user-images.githubusercontent.com/92526656/226432484-42a51898-0c5c-4c81-b3e5-fdd521dd3c52.png)
![Zrzut ekranu (6482)](https://user-images.githubusercontent.com/92526656/226432713-c4113d9b-4f39-4def-8545-eb309ed960a5.png)
![Zrzut ekranu (6483)](https://user-images.githubusercontent.com/92526656/226432882-d1cdebb0-a39f-4a64-9771-0f589496d2f7.png)
