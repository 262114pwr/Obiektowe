from django.contrib import admin
from .models import Ksiazka

admin.site.register(Ksiazka)

